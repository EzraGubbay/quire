# @ezragubbay/folio

The research register: warm paper, Source Serif 4 prose at a 68ch measure, Source Sans 3 chrome, IBM Plex Mono code, one oxblood accent, five semantic highlight kinds (claim, method, result, question, todo) that also colour the note graph. Light by default, dark via `theme="dark"` or the system preference.

```tsx
import '@ezragubbay/folio/styles.css';
import { FolioProvider, MathProvider, AppBar, Prose, Highlight, MathBlock } from '@ezragubbay/folio';

<FolioProvider theme="system">
  <MathProvider macros={{ E: '\\mathbb{E}' }}>
    <AppBar project="Sparse attention survey" tabs={[...]} />
    <Prose>
      <p>… <Highlight kind="claim">the bound is tight when…</Highlight></p>
      <MathBlock tex="\E[x]" number="4" />
    </Prose>
  </MathProvider>
</FolioProvider>
```

Styling idiom: CSS modules inside the package; your own layout glue uses the `--eg-*` and `--folio-*` custom properties (`var(--eg-surface)`, `var(--folio-hl-claim)`), never ad-hoc colours. Core primitives (`Button`, `Link`, `Icon`, `Mark`, ...) are re-exported.
