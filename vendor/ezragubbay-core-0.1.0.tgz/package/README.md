# @ezragubbay/core

The universal layer under Folio and Forge: spacing, motion, focus and control-size tokens as CSS custom properties, plus six primitives that both registers share.

- `Button` (`primary` / `secondary` / `ghost`, `md` / `sm`)
- `Link` (with `crossing="to-research" | "to-engineering"` for links that change register)
- `Icon` (a Lucide icon at the system's 1.5 stroke and 16/20/24 sizes)
- `VisuallyHidden`, `FocusRing`
- `Mark` (the EG monogram, direction A "shared stem"; `monogram` / `wordmark` / `lockup`)

Components read register-owned variables (`--eg-bg`, `--eg-accent`, `--eg-font-ui`, ...). Import a register's stylesheet to set them; core ships neutral fallbacks so it renders alone.

```tsx
import '@ezragubbay/core/styles.css';
import { Button, Mark } from '@ezragubbay/core';
```
